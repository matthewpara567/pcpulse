from .models import HealthCheck, Snapshot


def run_checks(snapshot: Snapshot) -> list[HealthCheck]:
    """Run conservative, read-only health checks over a snapshot."""
    checks: list[HealthCheck] = []
    mem = snapshot.memory.used_percent

    if mem is None:
        checks.append(
            HealthCheck("memory.available", "unknown", "Memory usage is unavailable.")
        )
    elif mem >= 95:
        checks.append(
            HealthCheck(
                "memory.usage",
                "error",
                "Memory usage is critically high.",
                {"used_percent": mem},
            )
        )
    elif mem >= 85:
        checks.append(
            HealthCheck(
                "memory.usage",
                "warning",
                "Memory usage is high.",
                {"used_percent": mem},
            )
        )
    else:
        checks.append(
            HealthCheck(
                "memory.usage",
                "ok",
                "Memory usage is within the normal threshold.",
                {"used_percent": mem},
            )
        )

    for disk in snapshot.disks:
        value = disk.used_percent
        if value is None:
            status, message = "unknown", f"Disk usage unavailable for {disk.path}."
        elif value >= 95:
            status, message = "error", f"Disk usage is critically high on {disk.path}."
        elif value >= 85:
            status, message = "warning", f"Disk usage is high on {disk.path}."
        else:
            status, message = (
                "ok",
                f"Disk usage is within the normal threshold on {disk.path}.",
            )
        checks.append(
            HealthCheck(
                f"disk.usage:{disk.path}",
                status,
                message,
                {"used_percent": value},
            )
        )
    return checks
