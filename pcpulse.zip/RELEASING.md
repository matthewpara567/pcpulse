# Releasing

1. Update the version in `pyproject.toml`.
2. Update `CHANGELOG.md`.
3. Run `pytest`, `ruff`, and `mypy`.
4. Review public API and schema changes.
5. Create a signed or annotated version tag.
6. Push the tag and build the package.

Do not publish a release with known failing tests or undocumented breaking changes.
