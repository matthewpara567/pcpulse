# Architecture

PCPulse separates collection, models, serialization, health checks, and the CLI.

Collectors read local OS information and return typed models. Serialization converts those models to stable external formats. Health checks interpret collected values without modifying the machine. The CLI is an interface over the library rather than the source of truth.

This separation lets downstream applications import PCPulse without scraping terminal output.
