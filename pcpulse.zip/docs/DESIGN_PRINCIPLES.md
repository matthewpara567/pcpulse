# Design Principles

- **Local-first:** the core collector does not require a network service.
- **Privacy-first:** identity information is opt-in.
- **Structured:** machine-readable data is a first-class interface.
- **Best-effort:** unavailable metrics are represented as unavailable rather than guessed.
- **Read-only:** diagnostics should not silently modify the host.
- **Small core:** new features must justify long-term maintenance cost.
- **Compatibility:** schema and API changes should be deliberate and documented.
