# PCPulse

**Local-first, privacy-conscious, cross-platform PC diagnostics for humans, scripts, support tools, and developer applications.**

PCPulse is a small Python library and command-line tool for collecting useful system information without requiring a remote service. It turns common OS and hardware facts into structured data that can be consumed by people, scripts, support workflows, and other applications.

> **Status:** Alpha (`0.1.0`). APIs and the snapshot schema may evolve before a stable release.

## Overview

PCPulse focuses on diagnostics that are easy to understand and easy to automate:

- operating system and kernel information
- CPU core counts and a short CPU utilization sample
- memory totals, availability, usage, and utilization
- mounted-disk capacity and utilization
- system uptime
- optional hostname and username collection
- JSON and Markdown serialization
- conservative local health checks
- a versioned snapshot schema

The default collection path is local and read-only. PCPulse does not implement telemetry, account login, remote collection, or background network reporting.

## Why PCPulse exists

System diagnostics are often trapped inside terminal commands, platform-specific scripts, or ad-hoc support tools. PCPulse provides a typed Python API and stable external representations so other software can consume diagnostics without scraping terminal output.

The project is intentionally small. The core goal is not to become a complete hardware-monitoring suite; it is to provide a dependable foundation for local system snapshots and tooling.

## Goals

- Provide a simple cross-platform diagnostics API.
- Make structured output a first-class interface.
- Keep identity data opt-in.
- Represent unavailable information honestly instead of guessing.
- Avoid modifying the host during diagnostics.
- Keep the dependency and maintenance surface small.
- Document compatibility and schema changes.

## Non-goals

PCPulse does not currently aim to:

- replace full-featured hardware monitoring applications
- provide a remote management platform
- collect or upload telemetry
- automatically change system configuration
- guarantee that every metric exists on every operating system
- diagnose every possible performance problem

## Features

### Local snapshots

`collect_snapshot()` returns typed models for CPU, memory, disks, platform metadata, and uptime.

### Privacy-conscious identity

Hostname and username are omitted by default. They are collected only when the caller explicitly passes `include_identity=True`.

### Machine-readable JSON

The snapshot can be serialized to indented JSON for scripts, support bundles, issue templates, or application integrations.

### Human-readable Markdown

Markdown output gives a compact report suitable for bug reports, support tickets, and documentation.

### Health checks

`run_checks()` evaluates memory and disk utilization against conservative thresholds and reports `ok`, `warning`, `error`, or `unknown` states.

### Versioned schema

Snapshot data is associated with an explicit schema version. A JSON Schema document is checked into the repository so downstream tools have a stable contract to build against.

## Installation

Python 3.10 or newer is supported.

```bash
python -m pip install pcpulse
```

For development:

```bash
git clone https://github.com/matthewpara567/pcpulse.git
cd pcpulse
python -m pip install -e '.[dev]'
```

## Quick start

Collect a snapshot:

```bash
pcpulse snapshot
```

Example output:

```text
OS: Linux
Kernel: 6.x
Architecture: x86_64
CPU: 8 logical / 4 physical
CPU load: 12.5%
Memory: 41.2% used
```

The exact values depend on the machine being inspected.

## CLI commands

### `pcpulse snapshot`

Collect a local snapshot and display a concise human-readable summary.

### `pcpulse snapshot --json`

Return the snapshot as JSON.

### `pcpulse snapshot --markdown`

Return a Markdown report.

### `pcpulse snapshot --include-identity`

Explicitly include the local hostname and username in the snapshot. This flag should be treated as a privacy-sensitive option when output is shared with others.

### `pcpulse doctor`

Collect a snapshot and run the current local health checks.

### `pcpulse doctor --json`

Return health-check results as JSON.

### `pcpulse schema`

Print the current snapshot schema version.

## Python API

The public API is intentionally small.

```python
from pcpulse import collect_snapshot, run_checks

snapshot = collect_snapshot()

print(snapshot.to_dict())

for check in run_checks(snapshot):
    print(check.status, check.message)
```

You can also serialize a snapshot explicitly:

```python
from pcpulse.serialization import to_json, to_markdown

print(to_json(snapshot))
print(to_markdown(snapshot))
```

## Snapshot format

A snapshot contains these top-level fields:

| Field | Meaning |
|---|---|
| `collected_at` | UTC timestamp for the collection operation |
| `schema_version` | Version of the external snapshot contract |
| `os` | Operating system name reported by Python |
| `kernel` | Kernel/release string reported by Python |
| `architecture` | Machine architecture reported by Python |
| `cpu` | Logical/physical core counts and utilization sample |
| `memory` | Total, available, used bytes and utilization |
| `disks` | Mounted disks and capacity information |
| `uptime_seconds` | Best-effort host uptime |
| `hostname` | Optional hostname; `null` by default |
| `username` | Optional username; `null` by default |
| `extra` | Reserved dictionary for future compatible extensions |

## JSON Schema

The schema for version `1.0` is stored at:

```text
schemas/snapshot-1.0.schema.json
```

Schema changes should be deliberate. A future breaking format should receive a new schema version instead of silently changing the meaning of existing fields.

## Health checks

The current checks use simple thresholds:

- memory usage below 85%: `ok`
- memory usage from 85% through 94.99%: `warning`
- memory usage at 95% or above: `error`
- disk usage follows the same thresholds
- unavailable metrics produce `unknown`

These checks are intentionally conservative. They are signals for support tooling, not a complete definition of system health.

## Privacy and security

PCPulse is designed to inspect the local host without modifying it.

By default:

- hostname is not collected
- username is not collected
- no credentials are requested
- no API key is required
- no telemetry endpoint is configured
- no background service is installed
- collected data stays in the process unless the caller chooses to print, save, or transmit it

When sharing JSON or Markdown output, inspect the contents first. Disk paths, operating-system strings, usernames, and hostnames can be sensitive in some environments.

See [SECURITY.md](SECURITY.md) for vulnerability-reporting guidance.

## Cross-platform behavior

PCPulse uses Python standard-library platform APIs plus `psutil` for common system metrics. Supported behavior depends on what the host operating system exposes.

A metric can legitimately be unavailable. PCPulse represents that condition with `null` values rather than inventing a value.

Filesystem permissions, container environments, virtual machines, and unusual mount configurations can also affect which disk information is available.

## Architecture

The project is split into focused layers:

```text
collectors -> models -> serialization
                  |
                  +-> health checks
                  |
                  +-> CLI
```

- **Collectors** read local system information.
- **Models** hold structured typed values.
- **Serialization** converts snapshots to external formats.
- **Health** interprets selected values without modifying the host.
- **CLI** provides a human- and script-friendly entry point over the library.

More detail is in [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).

## Repository structure

```text
pcpulse/
├── .github/
│   ├── CODEOWNERS
│   ├── dependabot.yml
│   ├── ISSUE_TEMPLATE/
│   │   └── bug_report.md
│   ├── PULL_REQUEST_TEMPLATE.md
│   └── workflows/
│       ├── ci.yml
│       └── release.yml
├── docs/
│   ├── ARCHITECTURE.md
│   └── DESIGN_PRINCIPLES.md
├── examples/
│   └── library_usage.py
├── schemas/
│   └── snapshot-1.0.schema.json
├── src/
│   └── pcpulse/
│       ├── __init__.py
│       ├── cli.py
│       ├── collectors.py
│       ├── health.py
│       ├── models.py
│       ├── py.typed
│       └── serialization.py
├── tests/
│   ├── test_cli.py
│   ├── test_collectors.py
│   ├── test_health.py
│   └── test_serialization.py
├── CHANGELOG.md
├── CODE_OF_CONDUCT.md
├── CONTRIBUTING.md
├── GOVERNANCE.md
├── LICENSE
├── MAINTAINERS.md
├── README.md
├── RELEASING.md
├── SECURITY.md
├── SUPPORT.md
└── pyproject.toml
```

## Development

Install the project with development dependencies:

```bash
python -m pip install -e '.[dev]'
```

Run the test suite:

```bash
pytest -q
```

Run the formatter/linter check:

```bash
ruff check .
```

Run static type checking:

```bash
mypy src
```

The GitHub Actions CI workflow runs these checks across the supported Python versions defined in the workflow matrix.

## Contributing

Contributions should be small, testable, and well documented. Behavior changes should include tests where practical.

Before opening a pull request, review:

- API compatibility
- schema compatibility
- cross-platform behavior
- privacy implications
- security implications
- test coverage

See [CONTRIBUTING.md](CONTRIBUTING.md) and [GOVERNANCE.md](GOVERNANCE.md).

## Issues and support

For reproducible bugs, include:

- PCPulse version
- Python version
- operating system
- minimal reproduction steps
- sanitized output

Do not paste secrets, access tokens, private keys, or other sensitive information into public issues.

## Roadmap

Potential future work includes:

- GPU inventory and utilization where platform support is reliable
- battery and power information
- temperature and fan information where safely available
- portable support-bundle generation
- pluggable collectors
- richer schema validation and compatibility tooling
- release integrity and provenance improvements

Roadmap items are proposals, not promises of a specific release schedule.

## Compatibility

PCPulse aims to preserve a small, predictable public API. Changes to public models, command names, serialization behavior, or schema meaning should be documented in the changelog.

A release may expose different metrics on different operating systems. Missing platform support should be represented explicitly rather than hidden behind platform-specific guesses.

## Design principles

The project follows six practical principles:

1. **Local-first:** diagnostics should work without a cloud service.
2. **Privacy-first:** sensitive identity information should be opt-in.
3. **Structured:** machine-readable output is a primary interface.
4. **Best-effort:** unavailable values are represented honestly.
5. **Read-only:** inspection should not silently change the machine.
6. **Compatibility:** public contracts should evolve deliberately.

See [docs/DESIGN_PRINCIPLES.md](docs/DESIGN_PRINCIPLES.md).

## Release process

The release workflow builds a source distribution and wheel when a version tag is pushed. Release preparation is documented in [RELEASING.md](RELEASING.md).

## Changelog

Release history is maintained in [CHANGELOG.md](CHANGELOG.md).

## License

PCPulse is released under the MIT License. See [LICENSE](LICENSE).

## Acknowledgements

PCPulse uses [`psutil`](https://github.com/giampaolo/psutil) for cross-platform access to common system metrics.

## Community files

This repository includes contribution, governance, security, support, and code-of-conduct guidance so that the project is usable as an open-source project rather than only as a code sample.
