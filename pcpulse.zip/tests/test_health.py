from pcpulse import collect_snapshot, run_checks


def test_health_checks_return_allowed_statuses() -> None:
    checks = run_checks(collect_snapshot())
    assert checks
    assert {check.status for check in checks} <= {"ok", "warning", "error", "unknown"}
