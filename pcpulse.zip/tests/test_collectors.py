from pcpulse.collectors import collect_snapshot


def test_snapshot_has_expected_metadata() -> None:
    snapshot = collect_snapshot()
    assert snapshot.schema_version == "1.0"
    assert snapshot.os
    assert snapshot.architecture
