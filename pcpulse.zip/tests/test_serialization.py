import json

from pcpulse import collect_snapshot
from pcpulse.serialization import to_json, to_markdown


def test_json_is_valid() -> None:
    snapshot = collect_snapshot()
    data = json.loads(to_json(snapshot))
    assert data["schema_version"] == "1.0"


def test_markdown_has_title() -> None:
    markdown = to_markdown(collect_snapshot())
    assert markdown.startswith("# PCPulse System Snapshot")
