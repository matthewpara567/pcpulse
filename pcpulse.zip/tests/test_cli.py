from pcpulse.cli import main


def test_schema_command(capsys) -> None:
    import sys

    original = sys.argv
    try:
        sys.argv = ["pcpulse", "schema"]
        assert main() == 0
    finally:
        sys.argv = original
    assert capsys.readouterr().out.strip() == "1.0"
