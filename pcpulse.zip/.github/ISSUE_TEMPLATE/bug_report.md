---
name: Bug report
about: Report a reproducible problem
---

## Environment

- PCPulse version:
- Python version:
- OS:

## Problem

What happened?

## Expected behavior

What did you expect?

## Reproduction

Provide the smallest reproduction you can. Remove sensitive information.
