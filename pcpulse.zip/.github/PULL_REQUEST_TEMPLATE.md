## Summary

Describe what this pull request changes and why.

## Testing

- [ ] `pytest -q`
- [ ] `ruff check .`
- [ ] `mypy src`

## Compatibility and privacy

Describe API, schema, platform, security, or privacy implications.
