# Contributing

Contributions are welcome. Keep changes focused and include tests for behavior changes.

## Development

```bash
python -m pip install -e '.[dev]'
pytest -q
ruff check .
mypy src
```

## Pull requests

Explain the problem, approach, testing performed, and compatibility or privacy implications.
